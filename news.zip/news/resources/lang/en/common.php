<?php

return [
    
    /*
    |--------------------------------------------------------------------------
    | Message notice success or danger: common
    |--------------------------------------------------------------------------
    */
    'msg_regist_success'                => 'Added successfully.',
    'msg_regist_danger'                 => 'Added failed.',
    'msg_edit_success'                  => 'Edited successfully.',
    'msg_edit_danger'                   => 'Edited failed.',
    'msg_delete_success'                => 'Deleted successfully.',
    'msg_delete_danger'                 => 'Deleted failed.',

    'msg_manage_login_danger'           => 'Username or password incorrect.',

];
