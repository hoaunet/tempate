<?php

return [

    'msg_manage_login_danger'             => 'ログインに失敗しました。',

    //category
    'msg_cts-adm_cat_regist_success'      => 'カテゴリが正常に追加されました。',
    'msg_cts-adm_cat_regist_danger'       => 'カテゴリ登録に失敗しました。',
    
    //message common
    'msg_cts-adm_del_success'             => '削除に成功しました。',
    'msg_cts-adm_regist_success'          => '登録が成功しました。',
    'msg_cts-adm_edit_success'            => '更新に成功しました。',
    'msg_cts-adm_del_danger'              => '削除に失敗しました。',
    'msg_cts-adm_regist_danger'           => 'レジスタが失敗しました。',
    'msg_cts-adm_edit_danger'             => '更新に失敗しました。',

];
