@extends('frontend.layouts.app')

@section('content')
<div id="secTitleBox" class="guide">
  <div class="secTitle">
    <p>お知らせ<span>Information</span></p>
  </div>
</div>
<div id="pan">
  <ul class="clear">
    <li><a href="{{ asset('') }}"><img src="{{ asset('') }}public/common/image/pan_home.png" width="22" height="20"></a>&nbsp;&gt;&nbsp;</li>
    <li>お知らせ</li>
  </ul>
</div>
<div id="second">
  <ul class="infoList">
    @if(!empty($infos))
      @foreach($infos as $ki => $info)
        <li> @if($info->info_type == 1)
              <a href="{{ $info->info1_url}}"  target="_blank" >
              @elseif($info->info_type == 2)
              <a href="{{ asset('public') }}{{ $info->info2_file}}"  target="_blank" >
              @else
              <a href="{{route('frontend.news.detail', $info->info_id)}}">
              @endif <span>{{format_date($info->info_date,'/')}}</span>{{$info->info_title}}</a></li>
      @endforeach
    @endif
 </ul>
  <div class="pager">
    <!--<ul>
      <li><a href="">＜</a></li>
      <li><a href="">１</a></li>
      <li class="now">２</li>
      <li><a href="">３</a></li>
      <li><a href="">＞</a></li>
    </ul>-->
    {{ $infos->links('vendor.pagination.ouslib') }}
  </div>



</div>
@endsection