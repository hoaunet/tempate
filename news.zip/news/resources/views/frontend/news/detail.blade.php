@extends('frontend.layouts.app')

@section('content')
<div id="secTitleBox" class="guide">
  <div class="secTitle">
    <p>お知らせ<span>Information</span></p>
  </div>
</div>
<div id="pan">
  <ul class="clear">
    <li><a href="{{ asset('') }}"><img src="{{ asset('') }}public/common/image/pan_home.png" width="22" height="20"></a>&nbsp;&gt;&nbsp;</li>
    <li><a href="{{route('frontend.news.index')}}">お知らせ</a>&nbsp;&gt;&nbsp;</li>
    <li>詳細</li>
  </ul>
</div>
<div id="second">
  <h2>{{$info->info_title}}</h2>
  <p>{{format_date($info->info_date,'/')}} </p>
  <div class="clear">
  <p>@if(!empty($info->info3_imgfile)) <img src="{{ asset('public') }}{{$info->info3_imgfile}}" width="300" height="226" class="alignright">@endif <?php echo str_replace(array("\r\n","\r","\n","\\r","\\n","\\r\\n"),"<br/>", $info->info3_contents); ?></p>
  </div>
  <ul class="wnDetail">
    @if(!empty($info->info3_url))
    <li><a href="{{$info->info3_url}}" target="_blank">{{$info->info3_url}}</a></li>
    @endif
     @if(!empty($info->info3_mail))
    <li><a href="mailto:{{$info->info3_mail}}">{{$info->info3_mail}}</a></li>
    @endif
    @if(!empty($info->info3_file))
    <li><a href="{{ asset('public') }}{{$info->info3_file}}" target="_blank">@if(!empty($info->info3_filename)){{$info->info3_filename}}@else ファイル @endif</a></li>
    @endif
  </ul>
  <div class="d_pager">@if(!empty($info_before->info_id))<a href="{{route('frontend.news.detail', $info_before->info_id)}}">&lt;&ensp;前の記事</a>@endif<a href="{{route('frontend.news.index')}}">一覧にもどる</a>@if(!empty($info_after->info_id))<a href="{{route('frontend.news.detail', $info_after->info_id)}}">次の記事&ensp;&gt;</a>@endif</div>


</div>
@endsection