@extends('frontend.layouts.app')
@section('content')
<main class="page-content">
        <section class="section-top-50">
          <div class="shell">
            <div class="range">
              <div class="cell-lg-6">
                <div class="offset-lg-negative-right-26">
                  <div class="post post-variant-1">
                    <div class="post-inner"><img class="img-responsive post-image" src="{{ asset('') }}public/images/politics-01.jpg" width="880" height="662" alt=""/>
                      <div class="post-caption">
                        <ul>
                        </ul>
                        <div>
                          <div class="h1"><a href="post-default.html">If Obama Had Governed Like This in 2009, He'd Be the Transformational President We Hoped For</a></div>
                          <div class="post-meta post-meta-hidden-outer">
                            <div class="post-meta-hidden">
                              <div class="icon text-gray icon-lg material-icons-share">
                                <ul>
                                  <li><a class="icon fa fa-facebook" href="#"></a></li>
                                  <li><a class="icon fa fa-twitter" href="#"></a></li>
                                  <li><a class="icon fa fa-google-plus" href="#"></a></li>
                                  <li><a class="icon fa fa-linkedin" href="#"></a></li>
                                  <li><a class="icon fa fa-pinterest" href="#"></a></li>
                                </ul>
                              </div>
                            </div>
                            <div><a class="post-meta-time" href="politics.html">
                                <time datetime="2016-06-06">2h ago</time></a></div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="cell-lg-6 offset-top-12 offset-lg-top-0 offset-lg-negative-left-26">
                <div class="range">
                  <div class="cell-sm-6">
                    <div class="offset-lg-negative-right-38 offset-sm-negative-right-23">
                      <div class="post post-variant-1">
                        <div class="post-inner"><img class="img-responsive post-image" src="{{ asset('') }}public/images/politics-02.jpg" width="426" height="327" alt=""/>
                          <div class="post-caption">
                            <ul>
                            </ul>
                            <div>
                              <div class="h5"><a href="post-default.html">How Russia filled the vacuum left by US withdrawal from the Middle East</a></div>
                              <div class="post-meta post-meta-hidden-outer">
                                <div class="post-meta-hidden">
                                  <div class="icon text-gray icon-lg material-icons-share">
                                    <ul>
                                      <li><a class="icon fa fa-facebook" href="#"></a></li>
                                      <li><a class="icon fa fa-twitter" href="#"></a></li>
                                      <li><a class="icon fa fa-google-plus" href="#"></a></li>
                                      <li><a class="icon fa fa-linkedin" href="#"></a></li>
                                      <li><a class="icon fa fa-pinterest" href="#"></a></li>
                                    </ul>
                                  </div>
                                </div>
                                <div><a class="post-meta-time" href="politics.html">
                                    <time datetime="2016-06-06">2h ago</time></a></div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="post post-variant-1">
                        <div class="post-inner"><img class="img-responsive post-image" src="{{ asset('') }}public/images/politics-03.jpg" width="426" height="327" alt=""/>
                          <div class="post-caption">
                            <ul>
                            </ul>
                            <div>
                              <div class="h5 text-italic"><a href="post-default.html">Rivals seize on Trump decision to skip Fox debate</a></div>
                              <div class="post-meta post-meta-hidden-outer">
                                <div class="post-meta-hidden">
                                  <div class="icon text-gray icon-lg material-icons-share">
                                    <ul>
                                      <li><a class="icon fa fa-facebook" href="#"></a></li>
                                      <li><a class="icon fa fa-twitter" href="#"></a></li>
                                      <li><a class="icon fa fa-google-plus" href="#"></a></li>
                                      <li><a class="icon fa fa-linkedin" href="#"></a></li>
                                      <li><a class="icon fa fa-pinterest" href="#"></a></li>
                                    </ul>
                                  </div>
                                </div>
                                <div><a class="post-meta-time" href="politics.html">
                                    <time datetime="2016-06-06">2h ago</time></a></div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="cell-sm-6 offset-top-12 offset-sm-top-0">
                    <div class="offset-lg-negative-left-14 offset-lg-negative-right-24 offset-sm-negative-left-23">
                      <div class="post post-variant-1">
                        <div class="post-inner"><img class="img-responsive post-image" src="{{ asset('') }}public/images/politics-04.jpg" width="426" height="327" alt=""/>
                          <div class="post-caption">
                            <ul>
                            </ul>
                            <div>
                              <div class="h5"><a href="post-default.html">Protesters claim Oregon refuge after Bundy arrest <span class='veil-lg reveal-xl-inline'>, but feds stand their ground</span>.</a></div>
                              <div class="post-meta post-meta-hidden-outer">
                                <div class="post-meta-hidden">
                                  <div class="icon text-gray icon-lg material-icons-share">
                                    <ul>
                                      <li><a class="icon fa fa-facebook" href="#"></a></li>
                                      <li><a class="icon fa fa-twitter" href="#"></a></li>
                                      <li><a class="icon fa fa-google-plus" href="#"></a></li>
                                      <li><a class="icon fa fa-linkedin" href="#"></a></li>
                                      <li><a class="icon fa fa-pinterest" href="#"></a></li>
                                    </ul>
                                  </div>
                                </div>
                                <div><a class="post-meta-time" href="politics.html">
                                    <time datetime="2016-06-06">2h ago</time></a></div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="post post-variant-1">
                        <div class="post-inner"><img class="img-responsive post-image" src="{{ asset('') }}public/images/politics-05.jpg" width="426" height="327" alt=""/>
                          <div class="post-caption">
                            <ul>
                            </ul>
                            <div>
                              <div class="h5"><a href="post-default.html">UN report iinvestigates whether Saudis bombed Yemen</a></div>
                              <div class="post-meta post-meta-hidden-outer">
                                <div class="post-meta-hidden">
                                  <div class="icon text-gray icon-lg material-icons-share">
                                    <ul>
                                      <li><a class="icon fa fa-facebook" href="#"></a></li>
                                      <li><a class="icon fa fa-twitter" href="#"></a></li>
                                      <li><a class="icon fa fa-google-plus" href="#"></a></li>
                                      <li><a class="icon fa fa-linkedin" href="#"></a></li>
                                      <li><a class="icon fa fa-pinterest" href="#"></a></li>
                                    </ul>
                                  </div>
                                </div>
                                <div><a class="post-meta-time" href="politics.html">
                                    <time datetime="2016-06-06">2h ago</time></a></div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        <section class="section-top-26">
          <div class="shell">
            <div class="range text-md-left">
              <div class="cell-lg-8">
                <div class="heading-divider">
                  <h2>Featured news</h2>
                </div>
                <div class="range offset-top-0">
                  <div class="text-sm-left cell-xs-preffix-1 cell-xs-10 cell-sm-6 cell-sm-preffix-0 cell-md-4 offset-top-45 offset-sm-top-0">
                    <div class="post post-variant-3">
                      <div class="post-inner"><img class="post-image" src="{{ asset('') }}public/images/politics-06.jpg" alt=""/>
                        <div class="post-caption">
                          <ul>
                          </ul>
                        </div>
                      </div>
                      <div class="h5 text-bold"><a class="post-link" href="post-default.html">Russia storms Syrian town hunting for pilot’s killer</a></div>
                      <div class="post-meta post-meta-hidden-outer">
                        <div class="post-meta-hidden">
                          <div class="icon text-gray icon-lg material-icons-share">
                            <ul>
                              <li><a class="icon fa fa-facebook" href="#"></a></li>
                              <li><a class="icon fa fa-twitter" href="#"></a></li>
                              <li><a class="icon fa fa-google-plus" href="#"></a></li>
                              <li><a class="icon fa fa-linkedin" href="#"></a></li>
                              <li><a class="icon fa fa-pinterest" href="#"></a></li>
                            </ul>
                          </div>
                        </div>
                        <div><a class="post-meta-time" href="politics.html">
                            <time datetime="2016-06-06">2h ago</time></a></div>
                      </div>
                    </div>
                  </div>
                  <div class="text-sm-left cell-xs-preffix-1 cell-xs-10 cell-sm-6 cell-sm-preffix-0 cell-md-4 offset-top-45 offset-sm-top-0">
                    <div class="post post-variant-3">
                      <div class="post-inner"><img class="post-image" src="{{ asset('') }}public/images/politics-07.jpg" alt=""/>
                        <div class="post-caption">
                          <ul>
                          </ul>
                        </div>
                      </div>
                      <div class="h5 text-bold"><a class="post-link" href="post-default.html">Report finds ISIS using Syrian dam to hide high-value prisoners</a></div>
                      <div class="post-meta post-meta-hidden-outer">
                        <div class="post-meta-hidden">
                          <div class="icon text-gray icon-lg material-icons-share">
                            <ul>
                              <li><a class="icon fa fa-facebook" href="#"></a></li>
                              <li><a class="icon fa fa-twitter" href="#"></a></li>
                              <li><a class="icon fa fa-google-plus" href="#"></a></li>
                              <li><a class="icon fa fa-linkedin" href="#"></a></li>
                              <li><a class="icon fa fa-pinterest" href="#"></a></li>
                            </ul>
                          </div>
                        </div>
                        <div><a class="post-meta-time" href="politics.html">
                            <time datetime="2016-06-06">2h ago</time></a></div>
                      </div>
                    </div>
                  </div>
                  <div class="text-sm-left cell-xs-preffix-1 cell-xs-10 cell-sm-6 cell-sm-preffix-0 cell-md-4 offset-top-45 offset-md-top-0">
                    <div class="post post-variant-3">
                      <div class="post-inner"><img class="post-image" src="{{ asset('') }}public/images/politics-08.jpg" alt=""/>
                        <div class="post-caption">
                          <ul>
                          </ul>
                        </div>
                      </div>
                      <div class="h5 text-bold"><a class="post-link" href="post-default.html">Sen. McCain assails Pentagon for relying on Russian rockets</a></div>
                      <div class="post-meta post-meta-hidden-outer">
                        <div class="post-meta-hidden">
                          <div class="icon text-gray icon-lg material-icons-share">
                            <ul>
                              <li><a class="icon fa fa-facebook" href="#"></a></li>
                              <li><a class="icon fa fa-twitter" href="#"></a></li>
                              <li><a class="icon fa fa-google-plus" href="#"></a></li>
                              <li><a class="icon fa fa-linkedin" href="#"></a></li>
                              <li><a class="icon fa fa-pinterest" href="#"></a></li>
                            </ul>
                          </div>
                        </div>
                        <div><a class="post-meta-time" href="politics.html">
                            <time datetime="2016-06-06">2h ago</time></a></div>
                      </div>
                    </div>
                  </div>
                  <div class="cell-xl-12 veil reveal-md-block offset-top-0">
                    <hr class="divider divider-dashed offset-top-20">
                    <div class="hidden"></div>
                  </div>
                  <div class="text-sm-left cell-xs-preffix-1 cell-xs-10 cell-sm-6 cell-sm-preffix-0 cell-md-4 offset-top-45 offset-md-top-0">
                    <div class="post post-variant-3">
                      <div class="post-inner"><img class="post-image" src="{{ asset('') }}public/images/politics-09.jpg" alt=""/>
                        <div class="post-caption">
                          <ul>
                          </ul>
                        </div>
                      </div>
                      <div class="h5 text-bold"><a class="post-link" href="post-default.html">FBI going 'right to the source' in Clinton email probe</a></div>
                      <div class="post-meta post-meta-hidden-outer">
                        <div class="post-meta-hidden">
                          <div class="icon text-gray icon-lg material-icons-share">
                            <ul>
                              <li><a class="icon fa fa-facebook" href="#"></a></li>
                              <li><a class="icon fa fa-twitter" href="#"></a></li>
                              <li><a class="icon fa fa-google-plus" href="#"></a></li>
                              <li><a class="icon fa fa-linkedin" href="#"></a></li>
                              <li><a class="icon fa fa-pinterest" href="#"></a></li>
                            </ul>
                          </div>
                        </div>
                        <div><a class="post-meta-time" href="politics.html">
                            <time datetime="2016-06-06">2h ago</time></a></div>
                      </div>
                    </div>
                  </div>
                  <div class="text-sm-left cell-xs-preffix-1 cell-xs-10 cell-sm-6 cell-sm-preffix-0 cell-md-4 offset-top-45 offset-md-top-0">
                    <div class="post post-variant-3">
                      <div class="post-inner"><img class="post-image" src="{{ asset('') }}public/images/politics-10.jpg" alt=""/>
                        <div class="post-caption">
                          <ul>
                          </ul>
                        </div>
                      </div>
                      <div class="h5 text-bold"><a class="post-link" href="post-default.html">GOP establishment still freaking that Trump or Cruz may win</a></div>
                      <div class="post-meta post-meta-hidden-outer">
                        <div class="post-meta-hidden">
                          <div class="icon text-gray icon-lg material-icons-share">
                            <ul>
                              <li><a class="icon fa fa-facebook" href="#"></a></li>
                              <li><a class="icon fa fa-twitter" href="#"></a></li>
                              <li><a class="icon fa fa-google-plus" href="#"></a></li>
                              <li><a class="icon fa fa-linkedin" href="#"></a></li>
                              <li><a class="icon fa fa-pinterest" href="#"></a></li>
                            </ul>
                          </div>
                        </div>
                        <div><a class="post-meta-time" href="politics.html">
                            <time datetime="2016-06-06">2h ago</time></a></div>
                      </div>
                    </div>
                  </div>
                  <div class="text-sm-left cell-xs-preffix-1 cell-xs-10 cell-sm-6 cell-sm-preffix-0 cell-md-4 offset-top-45 offset-md-top-0">
                    <div class="post post-variant-3">
                      <div class="post-inner"><img class="post-image" src="{{ asset('') }}public/images/politics-11.jpg" alt=""/>
                        <div class="post-caption">
                          <ul>
                          </ul>
                        </div>
                      </div>
                      <div class="h5 text-bold"><a class="post-link" href="post-default.html">Trump 2012: Rips candidates skipping debate, praises Kelly</a></div>
                      <div class="post-meta post-meta-hidden-outer">
                        <div class="post-meta-hidden">
                          <div class="icon text-gray icon-lg material-icons-share">
                            <ul>
                              <li><a class="icon fa fa-facebook" href="#"></a></li>
                              <li><a class="icon fa fa-twitter" href="#"></a></li>
                              <li><a class="icon fa fa-google-plus" href="#"></a></li>
                              <li><a class="icon fa fa-linkedin" href="#"></a></li>
                              <li><a class="icon fa fa-pinterest" href="#"></a></li>
                            </ul>
                          </div>
                        </div>
                        <div><a class="post-meta-time" href="politics.html">
                            <time datetime="2016-06-06">2h ago</time></a></div>
                      </div>
                    </div>
                  </div>
                  <div class="cell-xl-12 veil reveal-md-block offset-top-0">
                    <hr class="divider divider-dashed offset-top-20">
                    <div class="hidden"></div>
                  </div>
                  <div class="text-sm-left cell-xs-preffix-1 cell-xs-10 cell-sm-6 cell-sm-preffix-0 cell-md-4 offset-top-45 offset-md-top-0">
                    <div class="post post-variant-3">
                      <div class="post-inner"><img class="post-image" src="{{ asset('') }}public/images/politics-12.jpg" alt=""/>
                        <div class="post-caption">
                          <ul>
                          </ul>
                        </div>
                      </div>
                      <div class="h5 text-bold"><a class="post-link" href="post-default.html">Bloomberg bid could shake up 2016 race – would it make a difference?</a></div>
                      <div class="post-meta post-meta-hidden-outer">
                        <div class="post-meta-hidden">
                          <div class="icon text-gray icon-lg material-icons-share">
                            <ul>
                              <li><a class="icon fa fa-facebook" href="#"></a></li>
                              <li><a class="icon fa fa-twitter" href="#"></a></li>
                              <li><a class="icon fa fa-google-plus" href="#"></a></li>
                              <li><a class="icon fa fa-linkedin" href="#"></a></li>
                              <li><a class="icon fa fa-pinterest" href="#"></a></li>
                            </ul>
                          </div>
                        </div>
                        <div><a class="post-meta-time" href="politics.html">
                            <time datetime="2016-06-06">2h ago</time></a></div>
                      </div>
                    </div>
                  </div>
                  <div class="text-sm-left cell-xs-preffix-1 cell-xs-10 cell-sm-6 cell-sm-preffix-0 cell-md-4 offset-top-45 offset-md-top-0">
                    <div class="post post-variant-3">
                      <div class="post-inner"><img class="post-image" src="{{ asset('') }}public/images/politics-13.jpg" alt=""/>
                        <div class="post-caption">
                          <ul>
                          </ul>
                        </div>
                      </div>
                      <div class="h5 text-bold"><a class="post-link" href="post-default.html">US troops may stay in Afghanistan for decades to come</a></div>
                      <div class="post-meta post-meta-hidden-outer">
                        <div class="post-meta-hidden">
                          <div class="icon text-gray icon-lg material-icons-share">
                            <ul>
                              <li><a class="icon fa fa-facebook" href="#"></a></li>
                              <li><a class="icon fa fa-twitter" href="#"></a></li>
                              <li><a class="icon fa fa-google-plus" href="#"></a></li>
                              <li><a class="icon fa fa-linkedin" href="#"></a></li>
                              <li><a class="icon fa fa-pinterest" href="#"></a></li>
                            </ul>
                          </div>
                        </div>
                        <div><a class="post-meta-time" href="politics.html">
                            <time datetime="2016-06-06">2h ago</time></a></div>
                      </div>
                    </div>
                  </div>
                  <div class="text-sm-left cell-xs-preffix-1 cell-xs-10 cell-sm-6 cell-sm-preffix-0 cell-md-4 offset-top-45 offset-md-top-0">
                    <div class="post post-variant-3">
                      <div class="post-inner"><img class="post-image" src="{{ asset('') }}public/images/politics-14.jpg" alt=""/>
                        <div class="post-caption">
                          <ul>
                          </ul>
                        </div>
                      </div>
                      <div class="h5 text-bold"><a class="post-link" href="post-default.html">Gov. Scott: Jobs the most important issue for GOP candidates</a></div>
                      <div class="post-meta post-meta-hidden-outer">
                        <div class="post-meta-hidden">
                          <div class="icon text-gray icon-lg material-icons-share">
                            <ul>
                              <li><a class="icon fa fa-facebook" href="#"></a></li>
                              <li><a class="icon fa fa-twitter" href="#"></a></li>
                              <li><a class="icon fa fa-google-plus" href="#"></a></li>
                              <li><a class="icon fa fa-linkedin" href="#"></a></li>
                              <li><a class="icon fa fa-pinterest" href="#"></a></li>
                            </ul>
                          </div>
                        </div>
                        <div><a class="post-meta-time" href="politics.html">
                            <time datetime="2016-06-06">2h ago</time></a></div>
                      </div>
                    </div>
                  </div>
                </div>
                <hr class="divider divider-dashed offset-top-25">
                <ul class="pagination">
                  <li class="active"><a href="#">1</a></li>
                  <li><a href="#">2</a></li>
                  <li><a href="#">3</a></li>
                  <li><a href="#">4</a></li>
                  <li><a href="#">5</a></li>
                  <li><span>...</span></li>
                  <li><a href="#">10</a></li>
                  <li class="next veil reveal-md-inline"><a href="#">Next</a></li>
                </ul>
              </div>
              <div class="cell-lg-4 offset-top-36">
                <div class="range">
                  <div class="cell-sm-8 cell-sm-preffix-2 cell-lg-12 cell-lg-preffix-0 cell-xs-push-1 cell-lg-push-1">
                    <div class="bg-gray-base context-dark section-top-15 section-bottom-30 inset-p-left-6 inset-p-right-6">
                      <h3 class="heading-italic text-light">Search</h3>
                      <form class="form-inline-flex reveal-xs-flex" action="#">
                        <div class="form-group offset-bottom-0">
                          <input class="form-control" type="text" name="search1" placeholder="I'm looking for....">
                        </div>
                        <button class="btn btn-warning offset-xs-left-10 offset-top-12 offset-xs-top-0" type="submit">Search</button>
                      </form>
                    </div>
                  </div>
                  <div class="cell-sm-8 cell-sm-preffix-2 cell-lg-12 cell-lg-preffix-0 cell-xs-push-7 cell-lg-push-2 text-center text-lg-left">
                    <div class="bg-gray-light section-top-15 section-bottom-30 inset-p-left-6 inset-p-right-6 offset-top-45 offset-xl-top-60">
                      <h3 class="heading-italic text-light">Follow us</h3>
                      <p>Read our latest news on any of these social networks!</p>
                                      <ul class="list-inline-0">
                                        <li><a class="icon icon-circle fa-facebook icon-gray-base" href="#"></a></li>
                                        <li><a class="icon icon-circle fa-twitter icon-gray-base" href="#"></a></li>
                                        <li><a class="icon icon-circle fa-google-plus icon-gray-base" href="#"></a></li>
                                        <li><a class="icon icon-circle fa-youtube icon-gray-base" href="#"></a></li>
                                        <li><a class="icon icon-circle fa-feed icon-gray-base" href="#"></a></li>
                                      </ul>
                      <hr class="divider divider-dashed">
                      <h3 class="heading-italic text-light">Get latest news delivered daily!</h3>
                      <p>We will send you breaking news right to your inbox</p>
                      <form class="offset-top-20 rd-mailform-inline rd-mailform form-inline-flex reveal-xs-flex" data-form-output="form-output-global" data-form-type="subscribe" method="post" action="bat/rd-mailform.php">
                        <div class="form-wrap mfInput">
                          <input class="form-input" id="subscribe-form-email" type="text" name="email" data-constraints="@Email @Required">
                          <label class="form-label" for="subscribe-form-email">Your E-mail</label>
                        </div>
                        <button class="btn btn-warning">Subscribe</button>
                      </form>
                      <div class="rd-mailform-validate"></div>
                    </div>
                  </div>
                  <div class="cell-xs-12 cell-xs-push-3 cell-lg-push-3 offset-top-45">
                    <div class="heading-divider offset-top45">
                      <h3 class="heading-italic text-light">Latest news</h3>
                    </div>
                    <div class="range offset-top-30 offset-md-top-60">
                      <div class="cell-sm-6 cell-lg-12">
                                        <div class="post post-variant-2">
                                          <div class="unit unit-xl-horizontal">
                                            <div class="unit-left">
                                              <div class="post-inner">
                                                <div class="reveal-inline-block"><img class="post-image" src="{{ asset('') }}public/images/sidebar-01.jpg" width="150" height="115" alt=""></div>
                                                <div class="post-caption">
                                                  <ul>
                                                  </ul>
                                                </div>
                                              </div>
                                            </div>
                                            <div class="unit-body">
                                              <div class="h5 text-italic text-bold"><a class="post-link" href="post-default.html">Bradley Cooper’s &quot;Twin&quot; Causes Madness At Sundance Film Festival Opening</a></div>
                                              <div class="post-meta"><a class="post-meta-time" href="categories-list.html">
                                                  <time datetime="2016-06-06">Jan. 20, 2016</time></a></div>
                                            </div>
                                          </div>
                                        </div>
                        <hr class="divider divider-dashed">
                                        <div class="post post-variant-2">
                                          <div class="unit unit-xl-horizontal">
                                            <div class="unit-left">
                                              <div class="post-inner">
                                                <div class="reveal-inline-block"><img class="post-image" src="{{ asset('') }}public/images/sidebar-02.jpg" width="150" height="115" alt=""></div>
                                                <div class="post-caption">
                                                  <ul>
                                                  </ul>
                                                </div>
                                              </div>
                                            </div>
                                            <div class="unit-body">
                                              <div class="h5 text-bold"><a class="post-link" href="post-with-video.html">This Concept Jet Could Get You From New York To London In Under 11 Minutes</a></div>
                                              <div class="post-meta"><a class="post-meta-time" href="categories-list.html">
                                                  <time datetime="2016-06-06">Jan. 20, 2016</time></a></div>
                                            </div>
                                          </div>
                                        </div>
                        <hr class="divider divider-dashed">
                                        <div class="post post-variant-2">
                                          <div class="unit unit-xl-horizontal">
                                            <div class="unit-left">
                                              <div class="post-inner">
                                                <div class="reveal-inline-block"><img class="post-image" src="{{ asset('') }}public/images/sidebar-03.jpg" width="150" height="115" alt=""></div>
                                                <div class="post-caption">
                                                  <ul>
                                                  </ul>
                                                </div>
                                              </div>
                                            </div>
                                            <div class="unit-body">
                                              <div class="h5 text-bold"><a class="post-link" href="post-with-quote-2.html">3 Ways To Conquer Your Winter Laziness</a></div>
                                              <div class="post-meta"><a class="post-meta-time" href="categories-list.html">
                                                  <time datetime="2016-06-06">Jan. 20, 2016</time></a></div>
                                            </div>
                                          </div>
                                        </div>
                        <hr class="divider divider-dashed veil reveal-lg-block">
                      </div>
                      <div class="cell-sm-6 cell-lg-12 offset-lg-top-30">
                        <div class="divider divider-dashed veil-sm"></div>
                                        <div class="post post-variant-2">
                                          <div class="unit unit-xl-horizontal">
                                            <div class="unit-left">
                                              <div class="post-inner">
                                                <div class="reveal-inline-block"><img class="post-image" src="{{ asset('') }}public/images/sidebar-04.jpg" width="150" height="115" alt=""></div>
                                                <div class="post-caption">
                                                  <ul>
                                                  </ul>
                                                </div>
                                              </div>
                                            </div>
                                            <div class="unit-body">
                                              <div class="h5 text-bold"><a class="post-link" href="post-with-quote.html">UN report investigates whether Saudis bombed Yemen</a></div>
                                              <div class="post-meta"><a class="post-meta-time" href="categories-list.html">
                                                  <time datetime="2016-06-06">Jan. 20, 2016</time></a></div>
                                            </div>
                                          </div>
                                        </div>
                        <hr class="divider divider-dashed">
                                        <div class="post post-variant-2">
                                          <div class="unit unit-xl-horizontal">
                                            <div class="unit-left">
                                              <div class="post-inner">
                                                <div class="reveal-inline-block"><img class="post-image" src="{{ asset('') }}public/images/sidebar-05.jpg" width="150" height="115" alt=""></div>
                                                <div class="post-caption">
                                                  <ul>
                                                  </ul>
                                                </div>
                                              </div>
                                            </div>
                                            <div class="unit-body">
                                              <div class="h5 text-bold"><a class="post-link" href="post-with-audio.html">Greeks were warned - stop refugees wave, or we will kick you out</a></div>
                                              <div class="post-meta"><a class="post-meta-time" href="categories-list.html">
                                                  <time datetime="2016-06-06">Jan. 20, 2016</time></a></div>
                                            </div>
                                          </div>
                                        </div>
                        <hr class="divider divider-dashed">
                                        <div class="post post-variant-2">
                                          <div class="unit unit-xl-horizontal">
                                            <div class="unit-left">
                                              <div class="post-inner">
                                                <div class="reveal-inline-block"><img class="post-image" src="{{ asset('') }}public/images/sidebar-06.jpg" width="150" height="115" alt=""></div>
                                                <div class="post-caption">
                                                  <ul>
                                                  </ul>
                                                </div>
                                              </div>
                                            </div>
                                            <div class="unit-body">
                                              <div class="h5 text-bold"><a class="post-link" href="post-with-slider.html">FED made a brand new, bold statement on banks</a></div>
                                              <div class="post-meta"><a class="post-meta-time" href="categories-list.html">
                                                  <time datetime="2016-06-06">Jan. 20, 2016</time></a></div>
                                            </div>
                                          </div>
                                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="cell-xs-12 cell-xs-push-2 cell-lg-push-4 offset-top-45">
                    <div class="heading-divider">
                      <h3 class="heading-italic text-light">Recent posts</h3>
                    </div>
                    <div class="range offset-top-45">
                      <div class="cell-sm-6 cell-lg-12">
                                        <div class="post post-variant-1">
                                          <div class="post-inner"><img class="img-responsive post-image" src="{{ asset('') }}public/images/sidebar-07.jpg" width="536" height="411" alt="">
                                            <div class="post-caption">
                                              <ul>
                                                <li><a href="politics.html"><span class="label label-warning">News</span></a></li>
                                              </ul>
                                              <div>
                                                <div class="h4 text-normal font-accent-2"><a href="post-with-slider.html">Bill Maher & Macfarlene: ‘Serial Anti-Catholic Bigots’ - Catholic League</a></div>
                                                                <div class="post-meta post-meta-hidden-outer">
                                                                  <div class="post-meta-hidden">
                                                                    <div class="icon text-gray icon-lg material-icons-share">
                                                                      <ul>
                                                                        <li><a class="icon fa fa-facebook" href="#"></a></li>
                                                                        <li><a class="icon fa fa-twitter" href="#"></a></li>
                                                                        <li><a class="icon fa fa-google-plus" href="#"></a></li>
                                                                        <li><a class="icon fa fa-linkedin" href="#"></a></li>
                                                                        <li><a class="icon fa fa-pinterest" href="#"></a></li>
                                                                      </ul>
                                                                    </div>
                                                                  </div>
                                                                  <div class="element-groups-custom veil reveal-md-block"><a class="post-meta-author" href="categories-grid.html">Brian Williamson</a><a class="post-meta-time" href="categories-grid.html">
                                                                      <time datetime="2016-06-06">2h ago</time></a></div>
                                                                </div>
                                              </div>
                                            </div>
                                          </div>
                                        </div>
                        <hr class="divider divider-dashed">
                                        <div class="post post-variant-1">
                                          <div class="post-inner"><img class="img-responsive post-image" src="{{ asset('') }}public/images/sidebar-08.jpg" width="536" height="411" alt="">
                                            <div class="post-caption">
                                              <ul>
                                                <li><a href="politics.html"><span class="label label-warning">News</span></a></li>
                                              </ul>
                                              <div>
                                                <div class="h4 text-normal font-accent-2"><a href="post-with-audio.html">Spotify aims to raise $500M in debt</a></div>
                                                                <div class="post-meta post-meta-hidden-outer">
                                                                  <div class="post-meta-hidden">
                                                                    <div class="icon text-gray icon-lg material-icons-share">
                                                                      <ul>
                                                                        <li><a class="icon fa fa-facebook" href="#"></a></li>
                                                                        <li><a class="icon fa fa-twitter" href="#"></a></li>
                                                                        <li><a class="icon fa fa-google-plus" href="#"></a></li>
                                                                        <li><a class="icon fa fa-linkedin" href="#"></a></li>
                                                                        <li><a class="icon fa fa-pinterest" href="#"></a></li>
                                                                      </ul>
                                                                    </div>
                                                                  </div>
                                                                  <div class="element-groups-custom veil reveal-md-block"><a class="post-meta-author" href="categories-grid.html">Brian Williamson</a><a class="post-meta-time" href="categories-grid.html">
                                                                      <time datetime="2016-06-06">2h ago</time></a></div>
                                                                </div>
                                              </div>
                                            </div>
                                          </div>
                                        </div>
                        <hr class="divider divider-dashed veil-sm reveal-lg-block">
                      </div>
                      <div class="cell-sm-6 cell-lg-12 offset-lg-top-30">
                                        <div class="post post-variant-1">
                                          <div class="post-inner"><img class="img-responsive post-image" src="{{ asset('') }}public/images/sidebar-09.jpg" width="536" height="411" alt="">
                                            <div class="post-caption">
                                              <ul>
                                                <li><a href="politics.html"><span class="label label-warning">News</span></a></li>
                                              </ul>
                                              <div>
                                                <div class="h4 text-normal font-accent-2"><a href="post-with-quote.html">ICC Judges Start Investigations of Russian Aggressive War in Georgia in 2008</a></div>
                                                                <div class="post-meta post-meta-hidden-outer">
                                                                  <div class="post-meta-hidden">
                                                                    <div class="icon text-gray icon-lg material-icons-share">
                                                                      <ul>
                                                                        <li><a class="icon fa fa-facebook" href="#"></a></li>
                                                                        <li><a class="icon fa fa-twitter" href="#"></a></li>
                                                                        <li><a class="icon fa fa-google-plus" href="#"></a></li>
                                                                        <li><a class="icon fa fa-linkedin" href="#"></a></li>
                                                                        <li><a class="icon fa fa-pinterest" href="#"></a></li>
                                                                      </ul>
                                                                    </div>
                                                                  </div>
                                                                  <div class="element-groups-custom veil reveal-md-block"><a class="post-meta-author" href="categories-grid.html">Brian Williamson</a><a class="post-meta-time" href="categories-grid.html">
                                                                      <time datetime="2016-06-06">2h ago</time></a></div>
                                                                </div>
                                              </div>
                                            </div>
                                          </div>
                                        </div>
                        <hr class="divider divider-dashed">
                                        <div class="post post-variant-1">
                                          <div class="post-inner"><img class="img-responsive post-image" src="{{ asset('') }}public/images/sidebar-10.jpg" width="536" height="411" alt="">
                                            <div class="post-caption">
                                              <ul>
                                                <li><a href="politics.html"><span class="label label-warning">News</span></a></li>
                                              </ul>
                                              <div>
                                                <div class="h4 text-normal font-accent-2"><a href="post-with-quote-2.html">Michael Bloomberg Weighs on Independent Run For POTUS</a></div>
                                                                <div class="post-meta post-meta-hidden-outer">
                                                                  <div class="post-meta-hidden">
                                                                    <div class="icon text-gray icon-lg material-icons-share">
                                                                      <ul>
                                                                        <li><a class="icon fa fa-facebook" href="#"></a></li>
                                                                        <li><a class="icon fa fa-twitter" href="#"></a></li>
                                                                        <li><a class="icon fa fa-google-plus" href="#"></a></li>
                                                                        <li><a class="icon fa fa-linkedin" href="#"></a></li>
                                                                        <li><a class="icon fa fa-pinterest" href="#"></a></li>
                                                                      </ul>
                                                                    </div>
                                                                  </div>
                                                                  <div class="element-groups-custom veil reveal-md-block"><a class="post-meta-author" href="categories-grid.html">Brian Williamson</a><a class="post-meta-time" href="categories-grid.html">
                                                                      <time datetime="2016-06-06">2h ago</time></a></div>
                                                                </div>
                                              </div>
                                            </div>
                                          </div>
                                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="cell-xs-12 cell-xs-push-5 cell-lg-push-5 offset-top-36">
                    <div class="heading-divider">
                      <h3 class="heading-italic text-light">Recent comments</h3>
                    </div>
                    <div class="range offset-top-0">
                      <div class="cell-sm-8 cell-sm-preffix-2 cell-lg-12 cell-lg-preffix-0"><span class="small font-accent text-italic"><a href="categories-grid.html">Brian Williamson</a> on</span>
                        <h5><a class="text-gray-base" href="post-default.html">Bradley Cooper’s "Twin" Causes Madness At Sundance Film Festival Opening</a></h5>
                        <hr class="divider divider-dashed"><span class="small font-accent text-italic"><a href="categories-grid.html">Brian Williamson</a> on</span>
                        <h5><a class="text-gray-base" href="post-with-audio.html">3 Ways To Conquer Your Winter Laziness</a></h5>
                        <hr class="divider divider-dashed"><span class="small font-accent text-italic"><a href="categories-grid.html">Brian Williamson</a> on</span>
                        <h5><a class="text-gray-base" href="post-with-video.html">Greeks were warned - stop refugees wave, or we will kick you out</a></h5>
                      </div>
                      <div class="cell-sm-8 cell-sm-preffix-2 cell-lg-12 cell-lg-preffix-0 offset-top-36">
                        <div class="heading-divider">
                          <h3 class="heading-italic text-light">About Author</h3>
                        </div><a href="about-us.html"><img src="{{ asset('') }}public/images/sidebar-11.jpg" height="536" width="391" alt=""></a>
                      </div>
                    </div>
                  </div>
                  <div class="cell-xs-12 cell-xs-push-5 cell-lg-push-6 offset-top-36">
                    <div class="range text-sm-left">
                      <div class="cell-sm-6 cell-lg-12">
                        <div class="heading-divider">
                          <h3 class="heading-italic text-light">Gallery</h3>
                          <div class="instafeed sidebar-gallery" data-lightgallery="group" data-lg-thumbnail="false">
                            <div class="range range-ten">
                              <div class="cell-xs-5 cell-lg-2"><a class="thumbnail-variant-1" href="{{ asset('') }}public/images/index-gallery-01.jpg" data-lightgallery="item"><img src="{{ asset('') }}public/images/index-gallery-01.jpg" alt="" width="100" height="100"></a></div>
                              <div class="cell-xs-5 cell-lg-2"><a class="thumbnail-variant-1" href="{{ asset('') }}public/images/index-gallery-02.jpeg" data-lightgallery="item"><img src="{{ asset('') }}public/images/index-gallery-02.jpeg" alt="" width="100" height="100"></a></div>
                              <div class="cell-xs-5 cell-lg-2"><a class="thumbnail-variant-1" href="{{ asset('') }}public/images/index-gallery-03.jpg" data-lightgallery="item"><img src="{{ asset('') }}public/images/index-gallery-03.jpg" alt="" width="100" height="100"></a></div>
                              <div class="cell-xs-5 cell-lg-2"><a class="thumbnail-variant-1" href="{{ asset('') }}public/images/index-gallery-04.jpeg" data-lightgallery="item"><img src="{{ asset('') }}public/images/index-gallery-04.jpeg" alt="" width="100" height="100"></a></div>
                              <div class="cell-xs-5 cell-lg-2"><a class="thumbnail-variant-1" href="{{ asset('') }}public/images/index-gallery-05.jpeg" data-lightgallery="item"><img src="{{ asset('') }}public/images/index-gallery-05.jpeg" alt="" width="100" height="100"></a></div>
                              <div class="cell-xs-5 cell-lg-2"><a class="thumbnail-variant-1" href="{{ asset('') }}public/images/index-gallery-06.jpeg" data-lightgallery="item"><img src="{{ asset('') }}public/images/index-gallery-06.jpeg" alt="" width="100" height="100"></a></div>
                              <div class="cell-xs-5 cell-lg-2"><a class="thumbnail-variant-1" href="{{ asset('') }}public/images/index-gallery-07.jpeg" data-lightgallery="item"><img src="{{ asset('') }}public/images/index-gallery-07.jpeg" alt="" width="100" height="100"></a></div>
                              <div class="cell-xs-5 cell-lg-2"><a class="thumbnail-variant-1" href="{{ asset('') }}public/images/index-gallery-08.jpeg" data-lightgallery="item"><img src="{{ asset('') }}public/images/index-gallery-08.jpeg" alt="" width="100" height="100"></a></div>
                              <div class="cell-xs-5 cell-lg-2"><a class="thumbnail-variant-1" href="{{ asset('') }}public/images/index-gallery-09.jpeg" data-lightgallery="item"><img src="{{ asset('') }}public/images/index-gallery-09.jpeg" alt="" width="100" height="100"></a></div>
                              <div class="cell-xs-5 cell-lg-2"><a class="thumbnail-variant-1" href="{{ asset('') }}public/images/index-gallery-10.jpeg" data-lightgallery="item"><img src="{{ asset('') }}public/images/index-gallery-10.jpeg" alt="" width="100" height="100"></a></div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="cell-sm-6 cell-lg-12 offset-top-36 offset-sm-top-0 offset-lg-top-36">
                        <div class="heading-divider">
                          <h3 class="heading-italic text-light">Like Us On Facebook</h3>
                        </div>
                        <div id="fb-root">
                          <div class="fb-root fb-widget">
                            <div class="fb-page-responsive">
                              <div class="fb-page" data-href="https://www.facebook.com/TemplateMonster" data-tabs="timeline" data-height="350" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true">
                                <div class="fb-xfbml-parse-ignore">
                                  <blockquote cite="https://www.facebook.com/TemplateMonster"><a href="https://www.facebook.com/TemplateMonster">TemplateMonster</a></blockquote>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div class="heading-divider">
                          <h3 class="heading-italic text-light">Calendar</h3>
                        </div>
                        <div class="rd-calendar">
                          <div class="rdc-table">
                            <div class="rdc-panel text-center bg-gray-base context-dark">
                              <div class="h5">
                                <div class="rdc-month reveal-inline-block"></div><span>  </span>
                                <div class="rdc-fullyear reveal-inline-block"></div>
                              </div>
                            </div>
                          </div>
                          <div class="reveal-flex range-xs-justify"><a class="rdc-prev"></a><a class="rdc-next"></a></div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
@endsection