@extends('frontend.layouts.app')
@section('content')
<div id="secTitleBox" class="guide">
  <div class="secTitle">
    <p>利用案内<span>Guide</span></p>
  </div>
</div>
<div id="pan">
  <ul class="clear">
    <li><a href="{{route('frontend.homepage.index')}}"><img src="{{ asset('') }}public/common/image/pan_home.png" width="22" height="20"></a>&nbsp;&gt;&nbsp;</li>
    <li><a href="{{route('frontend.homepage.guide')}}">利用案内</a>&nbsp;&gt;&nbsp;</li>
    <li>図書館ガイドブック</li>
  </ul>
</div>
<div id="second">
  <h2>図書館ガイドブック</h2>
  <p>図書館で発行しているガイドブックは、印刷体を各図書館カウンター付近で配布していますが、PDF形式のファイルによりオンラインでも提供しております。必要なガイドブックを選択して下さい。</p>
  <div class="guidebook clear">
    <div class="guidebookText"><p><strong>図書館利用案内</strong><br>
    7.2MB</p></div>
<div class="guidebookImg"><a href="guidebook/riyoannai.pdf" target="_blank"><img src="{{ asset('') }}public/common/image/lib_small.gif" alt="図書館利用案内" width="200" height="140"></a></div>
  </div>
  <div class="guidebook clear">
    <div class="guidebookText">
      <p><strong>文献調査・図書館HPガイドブック</strong><br>
        2.8MB</p>
    </div>
    <div class="guidebookImg"><a href="guidebook/guidebook.pdf" target="_blank"><img src="{{ asset('') }}public/common/image/walk_mini.gif" alt="文献調査・図書館HPガイドブック" width="140" height="182"></a></div>
  </div>
  <div class="guidebook clear">
    <div class="guidebookText">
      <p><strong>OLION Manual</strong><br>
        4.2MB</p>
    </div>
    <div class="guidebookImg"><a href="guidebook/manual.pdf" target="_blank"><img src="{{ asset('') }}public/common/image/olion_small.gif" alt="OLION Manual" width="200" height="140"></a></div>
  </div>
  <ul class="pageMenu clear">
    <li><a href="{{route('frontend.homepage.detail', '1')}}">利用方法</a></li>
    <li><a href="{{route('frontend.homepage.detail', '2')}}">貸出期間や冊数</a></li>
    <li><a href="{{route('frontend.homepage.guidebooks')}}">図書館ガイドブック</a></li>
    <li><a href="haichizu/haichizu.html" target="_blank">館内配置図</a></li>
    <li><a href="http://www.ous.ac.jp/up_load_files/pdf/kakegakuen_map.pdf" target="_blank">キャンパスマップ</a></li>
    <li><a href="http://www.ous.ac.jp/access.php?jpml=accessmap" target="_blank">大学へのアクセス</a></li>
    <li><a href="u_libs.html" target="_blank">岡山県大学図書館利用案内</a></li>
    <li><a href="walk_in_user/gakugai_riyou.html">学外の方へ</a></li>
  </ul>
</div>
@endsection