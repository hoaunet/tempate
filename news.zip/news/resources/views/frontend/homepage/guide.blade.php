@extends('frontend.layouts.app')
@section('content')
<div id="secTitleBox" class="guide">
  <div class="secTitle">
    <p>利用案内<span>Guide</span></p>
  </div>
</div>
<div id="pan">
  <ul class="clear">
    <li><a href="{{route('frontend.homepage.index')}}"><img src="{{ asset('') }}public/common/image/pan_home.png" width="22" height="20"></a>&nbsp;&gt;&nbsp;</li>
    <li>利用案内</li>
  </ul>
</div>
<div id="second">
  <ul class="pageMenu clear" id="tableofcontents">
    <li><a href="{{route('frontend.homepage.detail', '1')}}">利用方法</a></li>
    <li><a href="{{route('frontend.homepage.detail', '2')}}">貸出期間や冊数</a></li>
    <li><a href="{{route('frontend.homepage.guidebooks')}}">図書館ガイドブック</a></li>
    <li><a href="haichizu/haichizu.html" target="_blank">館内配置図</a></li>
    <li><a href="http://www.ous.ac.jp/up_load_files/pdf/kakegakuen_map.pdf" target="_blank">キャンパスマップ</a></li>
    <li><a href="http://www.ous.ac.jp/access.php?jpml=accessmap" target="_blank">大学へのアクセス</a></li>
    <li><a href="u_libs.html" target="_blank">岡山県大学図書館利用案内</a></li>
    <li><a href="walk_in_user/gakugai_riyou.html">学外の方へ</a></li>
  </ul>
</div>  
@endsection