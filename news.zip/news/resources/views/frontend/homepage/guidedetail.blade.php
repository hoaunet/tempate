@extends('frontend.layouts.app')
@section('content')
 @if($id==1)
<div id="secTitleBox" class="guide">
  <div class="secTitle">
    <p>利用案内<span>Guide</span></p>
  </div>
</div>
<div id="pan">
  <ul class="clear">
    <li><a href="index.html"><img src="common/image/pan_home.png" width="22" height="20"></a>&nbsp;&gt;&nbsp;</li>
    <li><a href="guide.html">利用案内</a>&nbsp;&gt;&nbsp;</li>
    <li>利用方法</li>
  </ul>
</div>
<div id="second">
  <h2>利用方法</h2>
  <p>岡山理科大学図書館はさまざまな方にご利用いただけます。</p>
  <dl class="riyou">
    <dt>岡山理科大学の学生・教職員</dt>
    <dd>入学・就職と同時に利用できます。</dd>
  </dl>
  <dl class="riyou">
    <dt>関連学校(加計学園、関連学園)の生徒・学生・教職員</dt>
    <dd>最初に来館する時に、身分を証明するもの(学生証など)を持参して下さい。利用者登録をします。</dd>
  </dl>
  <dl class="riyou">
    <dt>岡山県大学図書館協議会相互協力協定参加大学・短大の学生と教職員</dt>
    <dd>最初に来館する時に、身分を証明するもの(学生証など)を持参して下さい。利用者登録をします。</dd>
  </dl>
  <dl class="riyou">
    <dt>本学卒業生</dt>
    <dd>図書・雑誌の利用については一般の市民と同じですが、郵便等で申し込めば大学にある文献のコピーを実費で送付します。(申し込み時に、本学卒業生であることをお書きそえください。「<a href="ill.html">学外文献の複写物の取り寄せ(学内または卒業生のみ）</a>」を参照してください。）
      在学時のシラバスのコピー申し込みは、こちらをクリックしてください。　－＞　「<a href="syllabus_copy.html">在学時のシラバス複写申し込み</a>」</dd>
  </dl>
  <dl class="riyou">
    <dt>一般の方</dt>
    <dd>図書館利用・閲覧はどなたでも自由にできます。<br>
      図書の貸出は、岡山県内在住者及び岡山県内事業所等勤務者が対象です。<br>
      最初に来館する時に、身分を証明するもの(免許証など)を持参して下さい。利用者登録をします。＝＞<a href="walk_in_user/riyou_shinsei_ippan.pdf">「図書館利用願」[PDF]</a></dd>
  </dl>
  <div class="atten clear" style="margin-top: 30px;">
    <p><a href="http://www.ous.ac.jp/up_load_files/pdf/kakegakuen_map.pdf" target="_blank"><img src="common/image/map_small.png" alt="学園マップ" width="200" height="183" class="alignright"></a><span class="atc" style="font-size:16px;"><strong>注意：</strong></span><br>
      図書館内の資料は、開館中はどなたでも自由に閲覧することができますが、貸出を希望される方は利用者登録が必要ですので、<strong>最初の来館は<span class="atc">平日の午後4時30分までにA２号館（旧１１号館）図書館カウンター</span>にお越し下さい。</strong></p>
  </div>
  @else
  <div id="secTitleBox" class="guide">
  <div class="secTitle">
    <p>利用案内<span>Guide</span></p>
  </div>
</div>
<div id="pan">
  <ul class="clear">
    <li><a href="index.html"><img src="common/image/pan_home.png" width="22" height="20"></a>&nbsp;&gt;&nbsp;</li>
    <li><a href="guide.html">利用案内</a>&nbsp;&gt;&nbsp;</li>
    <li>貸出期間や冊数</li>
  </ul>
</div>
<div id="second">
  <h2>貸出期間や冊数</h2>
  <p>利用される方によって貸出期間と冊数が異なりますので、ご注意ください。</p>
  <table class="kashidashi">
    <tr>
      <th rowspan="2">&nbsp;</th>
      <th colspan="3">学部学生</th>
      <th colspan="3">大学院生</th>
      <th colspan="3">教職員</th>
      <th colspan="3">一般利用者</th>
    </tr>
    <tr>
      <th>期間</th>
      <th>冊数</th>
      <th>更新回数</th>
      <th>期間</th>
      <th>冊数</th>
      <th>更新回数</th>
      <th>期間</th>
      <th>冊数</th>
      <th>更新回数</th>
      <th>期間</th>
      <th>冊数</th>
      <th>更新回数</th>
    </tr>
    <tr>
      <td class="koumoku">図書</td>
      <td>14日</td>
      <td>無制限</td>
      <td>1回</td>
      <td>28日</td>
      <td>無制限</td>
      <td>1回</td>
      <td>28日</td>
      <td>無制限</td>
      <td>2回</td>
      <td>14日</td>
      <td>30冊</td>
      <td>1回</td>
    </tr>
    <tr>
      <td class="koumoku">雑誌</td>
      <td>3日</td>
      <td>30冊</td>
      <td>不可</td>
      <td>3日</td>
      <td>30冊</td>
      <td>不可</td>
      <td>3日</td>
      <td>30冊</td>
      <td>不可</td>
      <td colspan=4>貸出しません</td>
    </tr>
  </table>
  <ol>
    <li>夏冬春季の学生休業期間中、図書の長期貸出を行います。（返却期限は休業期終了後10日目になります。）</li>
    <li>受け入れて30日以上たたない雑誌の貸し出しはしません。</li>
    <li>返却予定日が休館日の場合は、翌日とします。</li>
    <li>必要に応じて貸出冊数を制限することがあります。 </li>
    <li>貸出冊数はA1、A2、C2号館の3つの図書館の合計とします。</li>
  </ol>
  @endif
  <ul class="pageMenu clear">
    <li><a href="{{route('frontend.homepage.detail', '1')}}">利用方法</a></li>
    <li><a href="{{route('frontend.homepage.detail', '2')}}">貸出期間や冊数</a></li>
    <li><a href="{{route('frontend.homepage.guidebooks')}}">図書館ガイドブック</a></li>
    <li><a href="haichizu/haichizu.html" target="_blank">館内配置図</a></li>
    <li><a href="http://www.ous.ac.jp/up_load_files/pdf/kakegakuen_map.pdf" target="_blank">キャンパスマップ</a></li>
    <li><a href="http://www.ous.ac.jp/access.php?jpml=accessmap" target="_blank">大学へのアクセス</a></li>
    <li><a href="u_libs.html" target="_blank">岡山県大学図書館利用案内</a></li>
    <li><a href="walk_in_user/gakugai_riyou.html">学外の方へ</a></li>
  </ul>
</div>
@endsection