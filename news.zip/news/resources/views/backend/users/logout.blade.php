<!doctype html>
<html lang="ja">
<head>
<meta charset="utf-8">
<title>管理画面 | 岡山理科大学図書館</title>
<link href="{{ asset('') }}public/backend/css/style.css" rel="stylesheet" />
</head>

<body>
<table width="920" border="0" align="center" cellpadding="5" cellspacing="0">
  <tbody>
    <tr>
      <td class="col_1">■岡山理科大学図書館 Website 管理画面　＞　ログアウト</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td align="center">正常にログアウトされました。</td>
    </tr>
    <tr>
      <td align="center">&nbsp;</td>
    </tr>
    <tr>
      <td align="center">[ <a href="{{route('backend.users.login')}}">ログインはこちら</a> ]</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
    </tr>
  </tbody>
</table>
</body>
</html>
