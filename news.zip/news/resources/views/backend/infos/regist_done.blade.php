@extends('backend.layouts.app')
@section('content')
<table width="960" border="0" align="center" cellpadding="5" cellspacing="0">
  <tbody>
    <tr>
      <td width="150%" class="col_1">@if ($type==1) ■岡山理科大学図書館 Website 管理画面　＞　「お知らせ」管理　＞　新規登録 @elseif($type==2) ■岡山理科大学図書館 Website 管理画面　＞　「お知らせ」管理　＞　登録済み情報の変更 @else ■岡山理科大学図書館 Website 管理画面　＞　「お知らせ」管理　＞　登録済み情報の削除 @endif</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>@if ($type==1) 新規登録が完了しました。@elseif($type==2) 登録済み情報の変更が完了しました。 @else 登録済み情報の削除が完了しました。 @endif</td>
    </tr>
    <tr>
      <td align="center">&nbsp;</td>
    </tr>
    <tr>
      <td align="center"><input type="button" onClick="location.href='{{route('backend.infos.index')}}'" value="「お知らせ」一覧に戻る"></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
    </tr>
  </tbody>
</table>
@endsection
