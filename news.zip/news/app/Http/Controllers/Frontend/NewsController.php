<?php namespace App\Http\Controllers\Frontend;
use App\Http\Controllers\Frontend\FrontendController;
use App\Http\Models\InfoModel;

use Input;
use Validator;
use Session;
use Config;

class NewsController extends FrontendController
{
	public function index(){
		$clsInfo = new InfoModel();
		$infos = $clsInfo->getInfo();
		
		return view('frontend.news.index', compact('infos'));
	}

	public function detail($id){
		$info_id = $id;
		$clsInfo = new InfoModel();
		$info = $clsInfo->get_by_id($id);
		if(isset($info->info_date)){
			$info_after = $clsInfo->get_by_date_after($info->info_date,$id);		
			$info_before = $clsInfo->get_by_date_before($info->info_date,$id);
		}else{
			$info_after = NULL;
			$info_before = NULL;
		}
		return view('frontend.news.detail', compact('info', 'info_after','info_before','info_id'));
	}
}